package com.example.ai.engine

import com.example.ai.provider.*
import com.example.ai.rag.KnowledgeRetriever
import com.example.ai.router.QueryRouter
import com.example.model.*
import kotlinx.coroutines.withTimeoutOrNull

class ZakaAiEngine(
    private var settings: AppSettings
) {
    private val offlineProvider = OfflineExpertProvider()
    private var lastTopicSubject: String? = null

    fun updateSettings(newSettings: AppSettings) {
        this.settings = newSettings
    }

    /**
     * Executes the 13-stage AI response pipeline with strict timeout and fallback guarantees.
     * Guaranteed to never hang or return an infinite loading state.
     */
    suspend fun processQuery(
        rawQuery: String,
        history: List<ChatMessage>
    ): ChatMessage {
        // 1. Route query, normalize, detect language, typo correct, classify intent
        val routed = QueryRouter.route(rawQuery, lastTopicSubject)

        // Track subject for follow-up questions
        if (routed.matchedFastConcept != null) {
            lastTopicSubject = routed.matchedFastConcept.name
        }

        // 2. RAG Knowledge Retrieval
        val knowledge = KnowledgeRetriever.retrieve(routed)

        // 3. Select AI Provider
        val provider: AiProvider = when (settings.providerType) {
            AiProviderType.OFFLINE_EXPERT -> offlineProvider
            AiProviderType.GEMINI_CLOUD -> {
                val key = if (settings.geminiApiKey.isNotBlank()) settings.geminiApiKey else try {
                    com.example.BuildConfig.GEMINI_API_KEY
                } catch (e: Throwable) { "" }
                GeminiProvider(key)
            }
            AiProviderType.OLLAMA_LAN -> OllamaLanProvider(
                endpointUrl = settings.ollamaEndpoint,
                modelName = settings.ollamaModel
            )
            AiProviderType.OPENAI_COMPATIBLE -> offlineProvider // Fallback
        }

        // 4. Execute with strict 10-second timeout to prevent ANY hanging
        val result: ProviderResult? = try {
            withTimeoutOrNull(10000L) {
                provider.generateResponse(
                    routedQuery = routed,
                    knowledge = knowledge,
                    style = settings.teachingStyle,
                    history = history
                )
            }
        } catch (e: Exception) {
            ProviderResult.Error(
                errorMessage = "Execution error: ${e.message}",
                technicalDiagnostic = e.stackTraceToString()
            )
        }

        // 5. Response handling and graceful fallback
        return when (result) {
            is ProviderResult.Success -> {
                ChatMessage(
                    sender = MessageSender.AI,
                    text = result.answer,
                    providerUsed = result.providerName,
                    isFallback = false,
                    detectedLanguage = routed.detectedLanguage,
                    intent = routed.intent
                )
            }
            is ProviderResult.Error, null -> {
                // If cloud or local LAN failed, immediately fall back to Offline Expert
                val fallbackResult = offlineProvider.generateResponse(
                    routedQuery = routed,
                    knowledge = knowledge,
                    style = settings.teachingStyle,
                    history = history
                )

                val fallbackText = (fallbackResult as? ProviderResult.Success)?.answer ?: "Here is the Computer Science explanation for your question."

                val notice = if (routed.detectedLanguage == "Roman Urdu") {
                    "⚠️ *Notice: Cloud/Local AI service dastiyab nahi hai, is liye ZAKA AI ka verified Offline Expert mode use ho raha hai.*\n\n"
                } else {
                    "⚠️ *Notice: Configured AI service was unreachable or timed out; ZAKA AI Offline Expert mode has answered instead.*\n\n"
                }

                ChatMessage(
                    sender = MessageSender.AI,
                    text = notice + fallbackText,
                    providerUsed = "Offline Expert (Fallback)",
                    isFallback = true,
                    detectedLanguage = routed.detectedLanguage,
                    intent = routed.intent
                )
            }
        }
    }
}
