package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.engine.ZakaAiEngine
import com.example.data.course.CourseRepository
import com.example.data.db.AppDatabase
import com.example.data.repository.ZakaRepository
import com.example.model.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ZakaViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = ZakaRepository(database, application)
    private val aiEngine = ZakaAiEngine(repository.loadSettings())

    // Settings State
    private val _settings = MutableStateFlow(repository.loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    // Topic Progress & Bookmarks
    val topicProgress = repository.getTopicProgress().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Quiz History
    val quizResults = repository.getQuizResults().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Flashcard Mastery
    val flashcardMastery = repository.getFlashcardMastery().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // Chat History
    val chatHistory = repository.getChatHistory().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    // User Streak
    val userStreak = repository.getUserStreak().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), null
    )

    // Active AI State
    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    // Course Search State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<TopicNote>>(emptyList())
    val searchResults: StateFlow<List<TopicNote>> = _searchResults.asStateFlow()

    // Active Topic
    private val _selectedTopic = MutableStateFlow<TopicNote?>(CourseRepository.getAllTopics().firstOrNull())
    val selectedTopic: StateFlow<TopicNote?> = _selectedTopic.asStateFlow()

    // Active Quiz State
    private val _currentQuizQuestions = MutableStateFlow<List<McqItem>>(emptyList())
    val currentQuizQuestions: StateFlow<List<McqItem>> = _currentQuizQuestions.asStateFlow()

    private val _currentQuizIndex = MutableStateFlow(0)
    val currentQuizIndex: StateFlow<Int> = _currentQuizIndex.asStateFlow()

    private val _selectedOption = MutableStateFlow<Int?>(null)
    val selectedOption: StateFlow<Int?> = _selectedOption.asStateFlow()

    private val _isAnswerSubmitted = MutableStateFlow(false)
    val isAnswerSubmitted: StateFlow<Boolean> = _isAnswerSubmitted.asStateFlow()

    private val _quizScore = MutableStateFlow(0)
    val quizScore: StateFlow<Int> = _quizScore.asStateFlow()

    private val _isQuizFinished = MutableStateFlow(false)
    val isQuizFinished: StateFlow<Boolean> = _isQuizFinished.asStateFlow()

    // Active Flashcard State
    private val _currentFlashcards = MutableStateFlow<List<FlashcardItem>>(CourseRepository.getAllFlashcards())
    val currentFlashcards: StateFlow<List<FlashcardItem>> = _currentFlashcards.asStateFlow()

    private val _flashcardIndex = MutableStateFlow(0)
    val flashcardIndex: StateFlow<Int> = _flashcardIndex.asStateFlow()

    private val _isCardFlipped = MutableStateFlow(false)
    val isCardFlipped: StateFlow<Boolean> = _isCardFlipped.asStateFlow()

    init {
        // Increment streak check
        viewModelScope.launch {
            repository.incrementStreak()
        }
    }

    // Navigation & Topic Selection
    fun selectTopic(topicId: String) {
        val topic = repository.getTopic(topicId)
        if (topic != null) {
            _selectedTopic.value = topic
            viewModelScope.launch {
                repository.markTopicCompleted(topicId, topic.chapterId)
            }
        }
    }

    fun toggleBookmark(topicId: String, chapterId: Int, currentStatus: Boolean) {
        viewModelScope.launch {
            repository.toggleBookmark(topicId, chapterId, !currentStatus)
        }
    }

    // Search
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        _searchResults.value = CourseRepository.searchCourse(query)
    }

    // Chat / AI Teacher
    fun sendChatMessage(userText: String) {
        if (userText.isBlank() || _isAiThinking.value) return

        val userMessage = ChatMessage(
            sender = MessageSender.USER,
            text = userText.trim(),
            timestamp = System.currentTimeMillis()
        )

        viewModelScope.launch {
            repository.saveChatMessage(userMessage)
            _isAiThinking.value = true

            try {
                val currentHistory = chatHistory.value
                val aiResponse = aiEngine.processQuery(userText, currentHistory)
                repository.saveChatMessage(aiResponse)
            } catch (e: Exception) {
                val errNotice = ChatMessage(
                    sender = MessageSender.AI,
                    text = "System notice: Switched to offline expert mode.",
                    providerUsed = "Offline Expert",
                    isFallback = true
                )
                repository.saveChatMessage(errNotice)
            } finally {
                _isAiThinking.value = false
            }
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearChatHistory()
        }
    }

    // Quiz Controls
    fun startChapterQuiz(chapterId: Int) {
        val questions = repository.getMcqsForChapter(chapterId)
        _currentQuizQuestions.value = questions.ifEmpty { CourseRepository.getAllMcqs().take(5) }
        _currentQuizIndex.value = 0
        _selectedOption.value = null
        _isAnswerSubmitted.value = false
        _quizScore.value = 0
        _isQuizFinished.value = false
    }

    fun startCumulativeQuiz() {
        _currentQuizQuestions.value = repository.getAllMcqs().shuffled().take(10)
        _currentQuizIndex.value = 0
        _selectedOption.value = null
        _isAnswerSubmitted.value = false
        _quizScore.value = 0
        _isQuizFinished.value = false
    }

    fun selectQuizOption(optionIndex: Int) {
        if (!_isAnswerSubmitted.value) {
            _selectedOption.value = optionIndex
        }
    }

    fun submitQuizAnswer() {
        val selected = _selectedOption.value ?: return
        val currentQ = _currentQuizQuestions.value.getOrNull(_currentQuizIndex.value) ?: return

        _isAnswerSubmitted.value = true
        if (selected == currentQ.correctOptionIndex) {
            _quizScore.value += 1
        }
    }

    fun nextQuizQuestion() {
        val nextIdx = _currentQuizIndex.value + 1
        if (nextIdx < _currentQuizQuestions.value.size) {
            _currentQuizIndex.value = nextIdx
            _selectedOption.value = null
            _isAnswerSubmitted.value = false
        } else {
            _isQuizFinished.value = true
            // Persist quiz result
            viewModelScope.launch {
                val firstQ = _currentQuizQuestions.value.firstOrNull()
                val chapterId = firstQ?.let { CourseRepository.getAllTopics().firstOrNull { t -> t.mcqs.contains(it) }?.chapterId } ?: 1
                repository.saveQuizResult(
                    quizTitle = "Chapter $chapterId Practice Quiz",
                    chapterId = chapterId,
                    score = _quizScore.value,
                    total = _currentQuizQuestions.value.size
                )
            }
        }
    }

    // Flashcard Controls
    fun loadChapterFlashcards(chapterId: Int) {
        val cards = repository.getFlashcardsForChapter(chapterId)
        _currentFlashcards.value = cards.ifEmpty { CourseRepository.getAllFlashcards() }
        _flashcardIndex.value = 0
        _isCardFlipped.value = false
    }

    fun toggleCardFlip() {
        _isCardFlipped.value = !_isCardFlipped.value
    }

    fun nextFlashcard() {
        if (_currentFlashcards.value.isNotEmpty()) {
            _flashcardIndex.value = (_flashcardIndex.value + 1) % _currentFlashcards.value.size
            _isCardFlipped.value = false
        }
    }

    fun previousFlashcard() {
        if (_currentFlashcards.value.isNotEmpty()) {
            val prev = if (_flashcardIndex.value > 0) _flashcardIndex.value - 1 else _currentFlashcards.value.size - 1
            _flashcardIndex.value = prev
            _isCardFlipped.value = false
        }
    }

    fun markFlashcardMastery(isMastered: Boolean) {
        val currentCard = _currentFlashcards.value.getOrNull(_flashcardIndex.value) ?: return
        viewModelScope.launch {
            repository.setFlashcardMastery(currentCard.id, currentCard.chapterId, isMastered)
            nextFlashcard()
        }
    }

    // Settings Updates
    fun updateSettings(newSettings: AppSettings) {
        _settings.value = newSettings
        aiEngine.updateSettings(newSettings)
        repository.saveSettings(newSettings)
    }
}
